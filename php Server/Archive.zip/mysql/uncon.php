<?php
require("mysql/conect.php");
mysqli_close($link);
unset($sql,$result,$record);
?>