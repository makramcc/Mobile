	<?php
	require("mysql/connect.php");
	mysqli_query("SET NAMES UTF8");
	$city=$_REQUEST['city'];
	$brand=$_REQUEST['brand'];
	$model=$_REQUEST['model'];
	$f_date=$_REQUEST['first_date'];
	$e_date=$_REQUEST['end_date'];
	echo $city;

	//SELECT * FROM Car WHERE id_car= ANY(SELECT id_car FROM Oder WHERE id_car=ANY(SELECT id_car FROM Car	 WHERE car_brand='HONDA' AND car_model='CIVIC' AND city='ลำปาง') AND first_date NOT BETWEEN '2001/1/3' AND '2001/2/9' AND end_date NOT BETWEEN '2001/1/3' AND '2001/2/9')
	if($city!="" and $e_date!="" and $e_date!="" ){
	$sql="SELECT * FROM Car WHERE id_car=(SELECT Car_id FROM Oder WHERE city='$city' AND first_date NOT BETWEEN '$f_date' AND '$e_date' AND end_date NOT BETWEEN '$f_date' AND '$e_date')";
		if($model!=""){
			$sql .= " AND car_model='$model'";
		}
		if($brand !=""){
			$sql .= " AND car_brand='$brand'";
		}
	}else{
		$sql="SELECT * FROM Car ";
		$c=0;
		if($brand!=""){
			
			$sql .= "WHERE car_brand='$brand'";
			$c++;
		}
		if($model!=""){
			if($c==0){
				$sql .= "WHERE car_brand='$model'";
			}else{
				$sql .="AND car_model='$model'";
			}
			$c++;
		}
		if($city!=""){
			if($c==0){
				$sql .= "WHERE city='$city'";
			}else{
				$sql .="AND city='$city'";
			}
			$c++;
		}
	}
	

	$result=mysqli_query($link,$sql);
	while($arr=mysqli_fetch_assoc($result)){
		$resultJson[]=$arr;
		
	}
	echo json_encode($resultJson);

	//require("mysql/uncon.php");
?>

